// src/App.js

import React from 'react';
import './App.css';
import CodeExecutor from './CodeExecutor';

const App = () => {
    return (
        <div className="App">
            <header className="App-header">
                <h1>Code Execution Engine</h1>
            </header>
            <CodeExecutor />
        </div>
    );
};

export default App;